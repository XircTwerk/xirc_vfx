package com.xirctwerk.vfx.api.render;

import com.xirctwerk.vfx.core.Material;
import net.minecraft.class_310;
import net.minecraft.class_6367;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.opengl.*;

/** Explicit client-wide world post stack. No gameplay hooks; close/clear on owner teardown. */
public final class RenderEffects {
    private RenderEffects(){}
    private static Material world;private static RenderPipeline pipeline;private static class_6367 source;private static String error="";private static long started,frames;
    public static long frames(){return frames;}
    public static void world(Material material){RenderSystem.assertOnRenderThread();world=material;started=System.nanoTime();error="";if(material==null)release();}
    public static Material world(){return world;}
    public static String error(){return error;}
    public static double gpuMillis(){return pipeline==null?0:pipeline.gpuMillis();}
    public static void renderWorld(){var mc=class_310.method_1551();if(mc.field_1687==null){world=null;release();return;}if(world==null)return;var main=mc.method_1522();if(GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING)!=main.field_1476)return;
        try(var state=new RenderState()){if(main.field_1482>4096||main.field_1481>4096||(long)main.field_1482*main.field_1481>8_388_608)return;if(source==null)source=new class_6367(main.field_1482,main.field_1481,true,class_310.field_1703);else if(source.field_1482!=main.field_1482||source.field_1481!=main.field_1481)source.method_1234(main.field_1482,main.field_1481,class_310.field_1703);if(pipeline==null)pipeline=new RenderPipeline();
            GL11.glDisable(GL11.GL_SCISSOR_TEST);GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,main.field_1476);GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER,source.field_1476);GL30.glBlitFramebuffer(0,0,main.field_1482,main.field_1481,0,0,main.field_1482,main.field_1481,GL11.GL_COLOR_BUFFER_BIT|GL11.GL_DEPTH_BUFFER_BIT,GL11.GL_NEAREST);
            double seconds=(System.nanoTime()-started)/1e9;int output=pipeline.render(source.method_30277(),source.method_30278(),main.field_1482,main.field_1481,world,seconds,(seconds%5)/5);pipeline.blit(output,main);frames++;
        }catch(RuntimeException e){error=e.getMessage();org.slf4j.LoggerFactory.getLogger("XircRender").error("World material disabled",e);world=null;release();}}
    private static void release(){try(var state=new RenderState()){if(source!=null){source.method_1238();source=null;}if(pipeline!=null){pipeline.close();pipeline=null;}}}
}
