package com.xirctwerk.vfx.api.render;

import com.mojang.blaze3d.pipeline.*;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.*;
import net.minecraft.class_276;
import net.minecraft.class_310;
import net.minecraft.class_6367;

/** Named target pool with explicit ownership, depth access and a 128 MiB allocation budget. */
public final class RenderTargets implements AutoCloseable {
    private record Entry(class_6367 target,boolean depth){}
    private final Map<String,Entry> targets=new LinkedHashMap<>();
    public class_6367 acquire(String name,int width,int height,boolean depth){try(var scope=new RenderState()){RenderSystem.assertOnRenderThread();if(name==null||!name.matches("[a-z][a-z0-9_]{0,63}")||width<1||height<1||width>4096||height>4096)throw new IllegalArgumentException("Use a named target of 1..4096 pixels per axis.");var old=targets.get(name);long bytes=(long)width*height*(depth?8:4);for(var entry:targets.entrySet())if(!entry.getKey().equals(name))bytes+=(long)entry.getValue().target.field_1482*entry.getValue().target.field_1481*(entry.getValue().depth?8:4);if(bytes>128L*1024*1024||old==null&&targets.size()>=8)throw new IllegalArgumentException("Render pool exceeds 8 targets / 128 MiB.");if(old!=null&&old.depth!=depth){old.target.method_1238();targets.remove(name);old=null;}if(old==null){old=new Entry(new class_6367(width,height,depth,class_310.field_1703),depth);targets.put(name,old);}else if(old.target.field_1482!=width||old.target.field_1481!=height)old.target.method_1234(width,height,class_310.field_1703);return old.target;}}
    public void copyDepth(String name,class_276 source){var entry=targets.get(name);if(entry==null||!entry.depth)throw new IllegalArgumentException("Acquire a depth-enabled target first.");try(var state=new RenderState()){entry.target.method_29329(source);}}
    public void release(String name){try(var scope=new RenderState()){RenderSystem.assertOnRenderThread();var entry=targets.remove(name);if(entry!=null)entry.target.method_1238();}}
    @Override public void close(){try(var scope=new RenderState()){RenderSystem.assertOnRenderThread();for(var entry:targets.values())entry.target.method_1238();targets.clear();}}
}
