package com.xirctwerk.vfx.client;

import com.xirctwerk.vfx.core.*;
import java.io.*;
import java.nio.file.Path;
import java.util.*;
import java.util.function.Supplier;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public final class VfxClient {
    public static final String MOD_ID="xirc_vfx";
    public static final VfxClient INSTANCE=new VfxClient();
    public EffectFiles files;
    private final List<Playback> active=new ArrayList<>();
    private Playback editorPreview;private Supplier<Boolean> editorPaused=()->false;
    private final Map<String,class_2960> importedTextures=new HashMap<>();
    private Object level;
    private StudioScreen editor;
    public static final class Playback implements com.xirctwerk.vfx.api.Vfx.Handle {
        private Simulation simulation;
        private final Supplier<Effect.Vec> source;
        private final Supplier<Boolean> valid;
        private final PlaybackControls controls=new PlaybackControls();
        private com.google.gson.JsonObject authored;
        private final Map<String,Double> overrides=new HashMap<>();
        private long seed;
        private long simulationNanos;
        private Playback(Simulation simulation,Supplier<Effect.Vec> anchor,Supplier<Boolean> valid){this.simulation=simulation;this.source=anchor;this.valid=valid;this.seed=simulation.effect().seed();}
        public Simulation simulation(){return simulation;}
        public Supplier<Effect.Vec> anchor(){return ()->source.get().add(controls.offset());}
        public Supplier<Boolean> valid(){return valid;}
        public Effect.Color color(Effect.Color original){return controls.color(original);}
        public long simulationNanos(){return simulationNanos;}
        public boolean paused(){return controls.paused();}
        public void stop(){com.xirctwerk.vfx.api.Vfx.checkThread();controls.stop();}
        public boolean alive(){return controls.alive()&&valid.get()&&!simulation.finished();}
        public Playback move(Effect.Vec position){com.xirctwerk.vfx.api.Vfx.checkThread();controls.move(position.add(source.get().scale(-1)));return this;}
        public Playback rotate(Effect.Vec degrees){com.xirctwerk.vfx.api.Vfx.checkThread();controls.rotate(degrees);return this;}
        public Playback scale(double value){com.xirctwerk.vfx.api.Vfx.checkThread();controls.scale(value);return this;}
        public Playback tint(Effect.Color value){com.xirctwerk.vfx.api.Vfx.checkThread();controls.tint(value);return this;}
        public Playback pause(boolean value){com.xirctwerk.vfx.api.Vfx.checkThread();controls.pause(value);return this;}
        public Playback fadeOut(double seconds){com.xirctwerk.vfx.api.Vfx.checkThread();controls.fadeOut(seconds);return this;}
        public Playback parameter(String name,double value){
            com.xirctwerk.vfx.api.Vfx.checkThread();if(authored==null)throw new UnsupportedOperationException("This effect has no retained authored JSON");
            var next=new HashMap<>(overrides);next.put(name,value);var definition=Parameters.override(authored,next);var effect=EffectCodec.compile(definition);
            INSTANCE.checkBudget(effect,this);
            try{INSTANCE.checkResources(effect);}catch(IOException e){throw new IllegalArgumentException(e.getMessage(),e);}
            // Parameter edits restart only this instance so old sampled particles never mix definitions.
            simulation=new Simulation(effect,seed);overrides.clear();overrides.putAll(next);return this;
        }
    }
    float renderPartial(Playback playback){return playback.paused()||playback==editorPreview&&editorPaused.get()?1:class_310.method_1551().method_60646().method_60637(true);}
    private String editorTitle="Xirc's VFX";
    public String editorTitle(){return editorTitle;}
    public void setEditorTitle(String title){if(title==null||title.isBlank()||title.length()>128)throw new IllegalArgumentException("Editor title must contain 1..128 characters");editorTitle=title;}
    public synchronized void initialize(Path gameDirectory) {if(files==null)useProjectDirectory(gameDirectory.resolve("config").resolve(MOD_ID));}
    /** Host applications may retain their existing project directory; assets and schema stay canonical. */
    public synchronized void useProjectDirectory(Path directory) {
        try {
            files=new EffectFiles(directory);
            var existing=files.list(); for(String name:Templates.ALL_NAMES) if(!existing.contains(name)) files.save(name,Templates.create(name));
            for(String doc:List.of("AGENTS.md","schema/effect.schema.json","schema/material.schema.json","docs/AGENT_AUTHORING.md","docs/JSON_FORMAT.md","docs/RENDERING_API.md")) {
                try(InputStream in=VfxClient.class.getResourceAsStream("/studio_authoring/"+doc)) { if(in!=null) files.writeAuthoringDocument(doc,in); }
            }
        } catch(IOException e) { throw new IllegalStateException("Cannot initialize Studio projects",e); }
    }
    public void open() { if(editor==null) editor=new StudioScreen();class_310.method_1551().method_1507(editor); }
    public void checkResources(Effect effect) throws IOException {
        var manager=class_310.method_1551().method_1478();
        for(var e:effect.emitters()) {
            if(!importedTextures.containsKey(e.texture())) {
                byte[] stored=files.resource(e.texture());if(stored!=null) registerTexture(e.texture(),stored);
            }
            if(!importedTextures.containsKey(e.texture())&&manager.method_14486(class_2960.method_60654(e.texture())).isEmpty()) throw new IOException("Missing "+e.texture()+". Add its resource pack or choose a bundled texture.");
        }
    }
    public byte[] resource(String id) throws IOException {
        // Package imports are retained as data so they can be re-exported without reading GPU textures.
        if(packageResources.containsKey(id)) return packageResources.get(id).clone();
        byte[] stored=files.resource(id);if(stored!=null) return stored;
        var resource=class_310.method_1551().method_1478().method_14486(class_2960.method_60654(id));
        if(resource.isEmpty()) return null;
        try(InputStream in=resource.get().method_14482()) { byte[] bytes=in.readNBytes(4_194_305);if(bytes.length>4_194_304) throw new IOException("Texture exceeds 4 MiB: "+id);return bytes; }
    }
    private final Map<String,byte[]> packageResources=new HashMap<>();
    public void importPackage(String name) throws IOException {
        EffectFiles.Package pack=files.readPackage(name);
        // Decode all assets before replacing the current project or texture bindings.
        Map<String,class_1011> images=new HashMap<>();
        try {
            for(var asset:pack.resources().entrySet()) {
                byte[] bytes=asset.getValue();
                if(bytes.length<24||bytes[0]!=(byte)137||bytes[1]!=80||bytes[2]!=78||bytes[3]!=71) throw new IOException("Not a PNG: "+asset.getKey());
                var header=java.nio.ByteBuffer.wrap(bytes);int w=header.getInt(16),h=header.getInt(20);
                if(w<=0||h<=0||w>2048||h>2048||(long)w*h>4_194_304) throw new IOException("Texture dimensions exceed 2048 x 2048: "+asset.getKey());
                images.put(asset.getKey(),class_1011.method_4309(new ByteArrayInputStream(bytes)));
            }
            if(importedTextures.size()+images.keySet().stream().filter(k->!importedTextures.containsKey(k)).count()>64) throw new IOException("Imported texture limit reached (64). Restart Minecraft to clear package textures.");
            files.save(name,pack.effect());
            files.storeResources(pack.resources());
            for(var asset:images.entrySet()) {
                class_2960 old=importedTextures.get(asset.getKey()); if(old!=null) class_310.method_1551().method_1531().method_4615(old);
                var texture=class_310.method_1551().method_1531().method_4617("xirc_import",new class_1043(asset.getValue())); importedTextures.put(asset.getKey(),texture);
            }
            packageResources.putAll(pack.resources()); images.clear();
        } finally { images.values().forEach(class_1011::close); }
    }
    private void registerTexture(String id,byte[] bytes) throws IOException {
        if(importedTextures.size()>=64) throw new IOException("Imported texture limit reached (64).");
        if(bytes.length<24||bytes[0]!=(byte)137||bytes[1]!=80||bytes[2]!=78||bytes[3]!=71) throw new IOException("Not a PNG: "+id);
        var header=java.nio.ByteBuffer.wrap(bytes);int w=header.getInt(16),h=header.getInt(20);if(w<=0||h<=0||w>2048||h>2048) throw new IOException("Texture dimensions exceed 2048 x 2048: "+id);
        class_1011 image=class_1011.method_4309(new ByteArrayInputStream(bytes));
        importedTextures.put(id,class_310.method_1551().method_1531().method_4617("xirc_import",new class_1043(image)));packageResources.put(id,bytes.clone());
    }
    public class_2960 texture(String id) {
        if(!importedTextures.containsKey(id)) try {byte[] bytes=files.resource(id);if(bytes!=null) registerTexture(id,bytes);}catch(IOException ignored) { /* Playback/export reports errors explicitly; preview may show Minecraft's missing-texture marker. */ }
        return importedTextures.getOrDefault(id,class_2960.method_60654(id));
    }
    public List<Playback> playbacks() {if(editorPreview==null) return Collections.unmodifiableList(active);var result=new ArrayList<>(active);result.add(editorPreview);return Collections.unmodifiableList(result);}
    public Simulation editorSimulation() {return editorPreview==null?null:editorPreview.simulation();}
    public void stopEditorPreview() {editorPreview=null;}
    public Effect.Vec editorAnchor(){return editorPreview==null?null:editorPreview.anchor().get();}
    public void previewBesidePlayer(Effect effect,StudioScreen owner,Effect.Vec offset,Supplier<Boolean> paused) throws IOException {
        previewAt(effect,owner,()->vec(class_310.method_1551().field_1724.method_19538()).add(offset),paused);
    }
    public void previewWorld(Effect effect,StudioScreen owner,Effect.Vec point,Supplier<Boolean> paused) throws IOException {
        previewAt(effect,owner,()->point,paused);
    }
    private void previewAt(Effect effect,StudioScreen owner,Supplier<Effect.Vec> anchor,Supplier<Boolean> paused) throws IOException {
        var mc=class_310.method_1551();if(mc.field_1724==null||mc.field_1687==null) throw new IOException("Join a world first.");
        checkResources(effect);
        try{checkBudget(effect,editorPreview);}catch(IllegalArgumentException error){throw new IOException(error.getMessage(),error);}
        if(level!=mc.field_1687) {active.forEach(p->p.controls.stop());active.clear();editorPreview=null;BloomRenderer.release();level=mc.field_1687;}
        var player=mc.field_1724;var world=mc.field_1687;editorPaused=paused;
        if(editorPreview==null||!editorPreview.simulation().effect().equals(effect)) editorPreview=new Playback(new Simulation(effect),anchor,()->class_310.method_1551().field_1755==owner&&class_310.method_1551().field_1687==world&&!player.method_31481());
        else editorPreview=new Playback(editorPreview.simulation(),anchor,editorPreview.valid());
    }
    public Playback play(String name,Effect.Vec position) throws IOException { return play(new Project(files.load(name)),position); }
    public Playback play(Project project,Effect.Vec position) throws IOException {return play(project,position,project.effect().seed());}
    public Playback play(Project project,Effect.Vec position,long seed) throws IOException {return play(project,()->position,()->class_310.method_1551().field_1687!=null,seed);}
    public Playback play(Project project,Supplier<Effect.Vec> anchor,Supplier<Boolean> valid,long seed) throws IOException {
        com.xirctwerk.vfx.api.Vfx.checkThread();var playback=start(project.effect(),anchor,valid);playback.authored=project.json();playback.seed=seed;playback.simulation=new Simulation(project.effect(),seed);return playback;
    }
    public void attach(String name,int id) throws IOException {
        var world=class_310.method_1551().field_1687; if(world==null) throw new IOException("Join a world first."); class_1297 entity=world.method_8469(id);
        if(entity==null) throw new IOException("No loaded entity with ID "+id+". Use /xvfx me <name> for yourself.");
        start(EffectCodec.compile(files.load(name)),()->vec(entity.method_19538()),()->!entity.method_31481()&&class_310.method_1551().field_1687==world);
    }
    public void block(String name,class_2338 pos) throws IOException {
        var world=class_310.method_1551().field_1687;if(world==null||world.method_8320(pos).method_26215()) throw new IOException("Choose a loaded, non-air block.");
        start(EffectCodec.compile(files.load(name)),()->new Effect.Vec(pos.method_10263()+.5,pos.method_10264()+1,pos.method_10260()+.5),()->class_310.method_1551().field_1687==world&&!world.method_8320(pos).method_26215());
    }
    private Playback start(Effect effect,Supplier<Effect.Vec> anchor,Supplier<Boolean> valid) throws IOException {
        if(class_310.method_1551().field_1687==null) throw new IOException("Join a world first.");
        if(active.size()+(editorPreview==null?0:1)>=com.xirctwerk.vfx.api.VfxPerformance.limits().instances()) throw new IOException("16 effects are already playing. Use /xvfx stop.");checkResources(effect);
        // A new world is captured at start so switching worlds never carries old instances over.
        if(level!=class_310.method_1551().field_1687) { active.forEach(p->p.controls.stop());active.clear();editorPreview=null; level=class_310.method_1551().field_1687; }
        try{checkBudget(effect,null);}catch(IllegalArgumentException error){throw new IOException(error.getMessage(),error);}
        Playback playback=new Playback(new Simulation(effect),anchor,valid);active.add(playback);return playback;
    }
    private void checkBudget(Effect effect,Playback replacing){
        var others=playbacks().stream().filter(p->p!=replacing).toList();var limits=com.xirctwerk.vfx.api.VfxPerformance.limits();
        if(others.size()>=limits.instances()||others.stream().mapToDouble(p->EffectCodec.estimatedParticles(p.simulation.effect())).sum()+EffectCodec.estimatedParticles(effect)>limits.particles())throw new IllegalArgumentException("Playback exceeds configured instance/particle budget. Stop effects or lower emission/lifetime.");
        if(others.stream().mapToDouble(p->EffectCodec.estimatedGeometry(p.simulation.effect())).sum()+EffectCodec.estimatedGeometry(effect)>limits.quads())throw new IllegalArgumentException("Playback exceeds configured geometry budget. Stop effects or reduce mesh emissions.");
    }
    public void stop() { com.xirctwerk.vfx.api.IntegrationExamples.stop();active.forEach(Playback::stop);active.clear();editorPreview=null;com.xirctwerk.vfx.api.Vfx.clear(); }
    public void tick() {
        StudioSmokeTest.tick();
        com.xirctwerk.vfx.api.Vfx.tick();
        VfxNetworkClient.tick();com.xirctwerk.vfx.api.IntegrationExamples.tick();
        var mc=class_310.method_1551();if(mc.field_1687!=level) { active.forEach(p->p.controls.stop());active.clear();editorPreview=null;GeometryRenderer.release();BloomRenderer.release();com.xirctwerk.vfx.api.render.RenderEffects.world(null);level=mc.field_1687; }
        if(mc.field_1687==null||mc.method_1493()) return;
        int budget=com.xirctwerk.vfx.api.VfxPerformance.limits().particles()-(editorPreview==null?0:(int)Math.ceil(EffectCodec.estimatedParticles(editorPreview.simulation().effect())));
        for(Iterator<Playback> it=active.iterator();it.hasNext();) {
            Playback p=it.next();if(!p.alive()) {p.controls.stop(); it.remove();continue; }
            p.controls.tick();if(!p.controls.alive()){it.remove();continue;}if(p.controls.paused()){budget-=p.simulation.particles().size();p.simulationNanos=0;continue;}
            p.simulation.setInstancePose(p.controls.pose());long started=System.nanoTime();
            var anchor=p.anchor().get(); final var world=mc.field_1687;
            p.simulation.tick(anchor,point->!world.method_8320(class_2338.method_49637(point.x(),point.y(),point.z())).method_26220(world,class_2338.method_49637(point.x(),point.y(),point.z())).method_1110(),budget);
            p.simulationNanos=System.nanoTime()-started;budget-=p.simulation.particles().size();if(p.simulation.finished()) it.remove();
        }
        tickEditorPreview(com.xirctwerk.vfx.api.VfxPerformance.limits().particles()-active.stream().mapToInt(p->p.simulation().particles().size()).sum());
    }
    /** Bounded replay for editor scrubbing; ordinary playback instances are untouched. */
    void advanceEditorPreview(double target,int maxTicks) {
        if(editorPreview==null||class_310.method_1551().field_1687==null)return;
        var world=class_310.method_1551().field_1687;
        int budget=com.xirctwerk.vfx.api.VfxPerformance.limits().particles()-active.stream().mapToInt(p->p.simulation().particles().size()).sum();
        for(int i=0;i<maxTicks&&editorPreview.simulation().time()+Simulation.DT/2<target;i++)
            editorPreview.simulation().tick(editorPreview.anchor().get(),point->!world.method_8320(class_2338.method_49637(point.x(),point.y(),point.z())).method_26220(world,class_2338.method_49637(point.x(),point.y(),point.z())).method_1110(),budget);
    }
    private void tickEditorPreview(int budget) {
        if(editorPreview==null) return;if(!editorPreview.valid().get()) {editorPreview=null;return;}if(editorPaused.get()) return;
        var simulation=editorPreview.simulation();if(simulation.finished()) {var muted=simulation.muted();simulation=new Simulation(simulation.effect());simulation.setMuted(muted);editorPreview=new Playback(simulation,editorPreview.anchor(),editorPreview.valid());}
        var world=class_310.method_1551().field_1687;simulation.tick(editorPreview.anchor().get(),point->!world.method_8320(class_2338.method_49637(point.x(),point.y(),point.z())).method_26220(world,class_2338.method_49637(point.x(),point.y(),point.z())).method_1110(),budget);
    }
    public static Effect.Vec vec(net.minecraft.class_243 p) { return new Effect.Vec(p.field_1352,p.field_1351,p.field_1350); }
}
