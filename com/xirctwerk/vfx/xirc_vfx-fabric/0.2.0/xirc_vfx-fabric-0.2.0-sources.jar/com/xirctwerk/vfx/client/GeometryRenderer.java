package com.xirctwerk.vfx.client;

import com.xirctwerk.vfx.api.*;
import com.xirctwerk.vfx.core.*;
import com.xirctwerk.vfx.core.Effect.*;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.class_286;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_6367;
import net.minecraft.class_757;
import net.minecraft.client.*;
import org.lwjgl.opengl.GL11;
import java.util.*;

/** Nichirin-derived two-resolution geometry pipeline, isolated from buffered sprite rendering. */
final class GeometryRenderer {
    private record Batch(Object owner,int material) {}
    private static Object currentOwner;
    private record Colored(Geometry.Quad quad,Color color,Object owner) {Colored(Geometry.Quad quad,Color color){this(quad,color,currentOwner);}}
    private static final Map<Integer,class_6367> targets=new HashMap<>();
    private static int count;
    private static final List<Colored> bloomGeometry=new ArrayList<>();
    static boolean hasBloom(){return !bloomGeometry.isEmpty();}
    static void render(class_4587 pose,class_4184 camera) {
        class_310 mc=class_310.method_1551();if(mc.field_1687==null) {release();return;}
        Map<Batch,List<Colored>> groups=new LinkedHashMap<>();count=0;bloomGeometry.clear();
        for(var playback:VfxClient.INSTANCE.playbacks()) for(var p:playback.simulation().particles()) if(Geometry.supports(p.emitter.kind())) {
            currentOwner=playback;long generated=System.nanoTime();
            var point=p.interpolated(VfxClient.INSTANCE.renderPartial(playback));var origin=p.emitter.space().equals("local")?point.add(playback.anchor().get()):point;
            for(var q:Geometry.create(p,origin)) add(groups,p.emitter.pixelSize(),q,playback.color(p.color()),p.emitter.blend().equals("additive"),p.emitter.bloom());
            VfxPerformance.record(playback,0,0,System.nanoTime()-generated);
        }
        float partial=mc.method_60646().method_60637(true);
        for(var instance:Vfx.instances()) if(instance.alive()) {
            try {currentOwner=instance;long generated=System.nanoTime();instance.render(partial,(q,c)->add(groups,instance.style.pixelSize(),q,c,false,instance.style.bloom()));VfxPerformance.record(instance,0,0,System.nanoTime()-generated);}
            catch(RuntimeException error) {instance.stop();org.slf4j.LoggerFactory.getLogger("XircVfx").error("Stopped failing code visual",error);}
        }
        for(var trail:RibbonTrail.trails()) try {currentOwner=trail;long generated=System.nanoTime();trail.render((q,c)->add(groups,1,q,c));VfxPerformance.record(trail,0,0,System.nanoTime()-generated);} catch(RuntimeException error) {trail.close();org.slf4j.LoggerFactory.getLogger("XircVfx").error("Closed failing or over-budget trail",error); }
        if(groups.isEmpty()) return;
        var main=mc.method_1522();var oldShader=RenderSystem.getShader();
        boolean blend=GL11.glIsEnabled(GL11.GL_BLEND),depth=GL11.glIsEnabled(GL11.GL_DEPTH_TEST),cull=GL11.glIsEnabled(GL11.GL_CULL_FACE),mask=GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
        try {
            for(var entry:groups.entrySet()) {
                int pixel=entry.getKey().material()/2;boolean additive=(entry.getKey().material()&1)!=0;long started=System.nanoTime();
                class_6367 target=null;
                if(pixel>1) {
                    int width=Math.max(1,(main.field_1482+pixel-1)/pixel),height=Math.max(1,(main.field_1481+pixel-1)/pixel);
                    target=targets.get(pixel);
                    if(target==null) {target=new class_6367(width,height,true,class_310.field_1703);targets.put(pixel,target);}
                    else if(target.field_1482!=width||target.field_1481!=height) target.method_1234(width,height,class_310.field_1703);
                    target.method_58226(GL11.GL_NEAREST);target.method_1236(0,0,0,0);target.method_1230(class_310.field_1703);target.method_29329(main);target.method_1235(true);
                } else main.method_1235(true);
                draw(pose,camera,entry.getValue(),pixel>1,additive);
                VfxPerformance.record(entry.getKey().owner(),entry.getValue().size(),1,System.nanoTime()-started);
                if(pixel>1) {main.method_1235(true);RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();target.method_22594(main.field_1480,main.field_1477,false);}
            }
        } finally {
            main.method_1235(true);RenderSystem.setShader(()->oldShader);RenderSystem.depthMask(mask);
            if(blend) RenderSystem.enableBlend();else RenderSystem.disableBlend();
            if(depth) RenderSystem.enableDepthTest();else RenderSystem.disableDepthTest();
            if(cull) RenderSystem.enableCull();else RenderSystem.disableCull();
        }
    }
    private static void add(Map<Batch,List<Colored>> groups,int pixel,Geometry.Quad q,Color color) {add(groups,pixel,q,color,false);}
    private static void add(Map<Batch,List<Colored>> groups,int pixel,Geometry.Quad q,Color color,boolean additive) {add(groups,pixel,q,color,additive,0);}
    private static void add(Map<Batch,List<Colored>> groups,int pixel,Geometry.Quad q,Color color,boolean additive,double bloom) {
        if(count>=Math.min(65536,VfxPerformance.limits().quads()*2)) throw new IllegalStateException("Frame geometry exceeds 65536 quads");
        for(Vec v:List.of(q.a(),q.b(),q.c(),q.d())) if(!Double.isFinite(v.x())||!Double.isFinite(v.y())||!Double.isFinite(v.z())) throw new IllegalArgumentException("Mesh vertices must be finite");
        for(double c:new double[]{color.r(),color.g(),color.b(),color.a()}) if(!Double.isFinite(c)||c<0||c>1) throw new IllegalArgumentException("Mesh color channels must be 0..1");
        if(bloom>0)bloomGeometry.add(new Colored(q,new Color(color.r()*bloom/4,color.g()*bloom/4,color.b()*bloom/4,color.a())));
        count++;groups.computeIfAbsent(new Batch(currentOwner,pixel*2+(additive?1:0)),k->new ArrayList<>()).add(new Colored(q,color));
    }
    private static void draw(class_4587 pose,class_4184 camera,List<Colored> quads,boolean snap,boolean additive) {
        RenderSystem.setShader(class_757::method_34540);RenderSystem.enableBlend();if(additive)RenderSystem.blendFunc(GL11.GL_SRC_ALPHA,GL11.GL_ONE);else RenderSystem.defaultBlendFunc();RenderSystem.enableDepthTest();RenderSystem.depthMask(false);RenderSystem.disableCull();
        var buffer=class_289.method_1348().method_60827(class_293.class_5596.field_27382,class_290.field_1576);
        // Approximate back-to-front order improves intersecting translucent meshes.
        var position=camera.method_19326();quads.sort(Comparator.comparingDouble((Colored q)->distance(q.quad,position.field_1352,position.field_1351,position.field_1350)).reversed());
        for(var item:quads) for(Vec v:List.of(item.quad.a(),item.quad.b(),item.quad.c(),item.quad.d())) {
            double x=v.x(),y=v.y(),z=v.z();if(snap) {x=Math.round(x*16)/16.;y=Math.round(y*16)/16.;z=Math.round(z*16)/16.;}
            Color c=item.color;buffer.method_22918(pose.method_23760().method_23761(),(float)(x-position.field_1352),(float)(y-position.field_1351),(float)(z-position.field_1350)).method_22915((float)c.r(),(float)c.g(),(float)c.b(),(float)c.a());
        }
        class_286.method_43433(buffer.method_60800());
    }
    static void renderBloom(class_4587 pose,class_4184 camera) {
        var owners=new LinkedHashMap<Object,List<Colored>>();for(var item:bloomGeometry)owners.computeIfAbsent(item.owner(),k->new ArrayList<>()).add(item);
        for(var entry:owners.entrySet()){long started=System.nanoTime();draw(pose,camera,entry.getValue(),false,false);VfxPerformance.record(entry.getKey(),entry.getValue().size(),1,System.nanoTime()-started);}
    }
    private static double distance(Geometry.Quad q,double x,double y,double z) {Vec v=q.a().add(q.b()).add(q.c()).add(q.d()).scale(.25);return Math.pow(v.x()-x,2)+Math.pow(v.y()-y,2)+Math.pow(v.z()-z,2);}
    static void release() {targets.values().forEach(class_6367::method_1238);targets.clear();bloomGeometry.clear();}
}
