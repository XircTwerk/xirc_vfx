package com.xirctwerk.vfx.client;

import com.xirctwerk.vfx.core.*;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.class_1921;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.client.renderer.*;
import org.joml.Vector3f;

/** Buffered sprites/ribbons plus the independent procedural geometry and code-visual pass. */
public final class VfxRenderer {
    public static void render(class_4587 pose,class_4184 camera) {
        com.xirctwerk.vfx.api.VfxPerformance.beginFrame();
        renderParticles(pose,camera,false);
        GeometryRenderer.render(pose,camera);
        BloomRenderer.render(pose,camera);
        renderPivot(pose,camera);
    }
    private static void renderPivot(class_4587 pose,class_4184 camera){
        var studio=VfxClient.INSTANCE;var anchor=studio.editorAnchor();if(anchor==null)return;
        var c=camera.method_19326();var start=new Vector3f((float)(anchor.x()-c.field_1352),(float)(anchor.y()-c.field_1351),(float)(anchor.z()-c.field_1350));
        var buffers=class_310.method_1551().method_22940().method_23000();var type=SpriteMaterial.get(studio.texture("xirc_vfx_studio:textures/effect/spark.png"),true,false,false);var buffer=buffers.getBuffer(type);
        ribbon(pose,buffer,new Vector3f(start).add(-.25f,0,0),new Vector3f(start).add(.25f,0,0),.018f,new Effect.Color(1,.25,.25,1),class_765.field_32767,new Effect.Uv(0,0,1,1));
        ribbon(pose,buffer,new Vector3f(start),new Vector3f(start).add(0,.5f,0),.018f,new Effect.Color(.25,1,.35,1),class_765.field_32767,new Effect.Uv(0,0,1,1));
        ribbon(pose,buffer,new Vector3f(start).add(0,0,-.25f),new Vector3f(start).add(0,0,.25f),.018f,new Effect.Color(.3,.6,1,1),class_765.field_32767,new Effect.Uv(0,0,1,1));buffers.method_22994(type);
    }
    static void renderParticles(class_4587 pose,class_4184 camera,boolean bloom) {
        var studio=VfxClient.INSTANCE; var mc=class_310.method_1551(); if(mc.field_1687==null||studio.playbacks().isEmpty()) return;
        class_4597.class_4598 buffers=mc.method_22940().method_23000();
        var c=camera.method_19326();Vector3f right=new Vector3f(1,0,0).rotate(camera.method_23767()),up=new Vector3f(0,1,0).rotate(camera.method_23767());
        for(var playback:studio.playbacks()) {
            int quads=0,draws=0,batchQuads=0;class_1921 currentType=null;long started=System.nanoTime();
            float partial=studio.renderPartial(playback);
            var anchor=playback.anchor().get();
            for(var p:playback.simulation().particles()) {
                if(Geometry.supports(p.emitter.kind())) continue;
                if(bloom&&p.emitter.bloom()<=0)continue;
                var interpolated=p.interpolated(partial);var world=p.emitter.space().equals("local")?interpolated.add(anchor):interpolated;Vector3f pos=new Vector3f((float)(world.x()-c.field_1352),(float)(world.y()-c.field_1351),(float)(world.z()-c.field_1350));
                var type=SpriteMaterial.get(studio.texture(p.emitter.texture()),bloom||p.emitter.glow(),p.emitter.blend().equals("additive"),bloom);
                if(currentType!=null&&currentType!=type){buffers.method_22994(currentType);if(batchQuads>0)draws++;batchQuads=0;}currentType=type;int before=quads;
                class_4588 buffer=buffers.getBuffer(type);var color=playback.color(p.color());if(bloom)color=new Effect.Color(color.r()*p.emitter.bloom()/4,color.g()*p.emitter.bloom()/4,color.b()*p.emitter.bloom()/4,color.a());float size=(float)p.size();
                int light=(bloom||p.emitter.glow())?class_765.field_32767:class_761.method_23794(mc.field_1687,net.minecraft.class_2338.method_49637(world.x(),world.y(),world.z()));
                if(p.emitter.kind().equals("beam")) {
                    var d=p.direction().normalize().scale(p.emitter.length()*p.transformScale());Vector3f end=new Vector3f(pos).add((float)d.x(),(float)d.y(),(float)d.z());quads+=ribbon(pose,buffer,pos,end,size,color,light,p.emitter.textureAnimation().uv(p.interpolatedAge(partial)));
                } else if(p.emitter.kind().equals("trail")&&!p.history.isEmpty()) {
                    Vector3f last=pos;int i=0;
                    for(var point:p.history) {
                        var v=p.emitter.space().equals("local")?point.add(anchor):point;Vector3f next=new Vector3f((float)(v.x()-c.field_1352),(float)(v.y()-c.field_1351),(float)(v.z()-c.field_1350));
                        quads+=ribbon(pose,buffer,last,next,size*(1-(float)i/p.emitter.trailPoints()),color,light,p.emitter.textureAnimation().uv(p.interpolatedAge(partial)));last=next;i++;
                    }
                } else {
                    var velocity=p.renderVelocity();double angle=p.angle();if(p.emitter.motion().align()&&velocity.length()>1e-6)angle+=Math.toDegrees(Math.atan2(velocity.x()*up.x+velocity.y()*up.y+velocity.z()*up.z,velocity.x()*right.x+velocity.y()*right.y+velocity.z()*right.z));
                    float radians=(float)Math.toRadians(angle),co=(float)Math.cos(radians),si=(float)Math.sin(radians);
                    Vector3f r=new Vector3f(right).mul(co).add(new Vector3f(up).mul(si)).mul(size*.5f*(float)(p.emitter.aspect()*p.emitter.motion().stretchFactor(velocity)));
                    Vector3f u=new Vector3f(up).mul(co).sub(new Vector3f(right).mul(si)).mul(size*.5f);
                    var uv=p.emitter.textureAnimation().uv(p.interpolatedAge(partial));quads++;quad(pose,buffer,new Vector3f(pos).sub(r).sub(u),new Vector3f(pos).sub(r).add(u),new Vector3f(pos).add(r).add(u),new Vector3f(pos).add(r).sub(u),color,light,uv);
                }
                batchQuads+=quads-before;
            }
            if(currentType!=null){buffers.method_22994(currentType);if(batchQuads>0)draws++;}
            com.xirctwerk.vfx.api.VfxPerformance.record(playback,quads,draws,System.nanoTime()-started);
        }
        // Flush only our texture types, leaving other mods' buffered geometry untouched.
    }
    private static int ribbon(class_4587 pose,class_4588 b,Vector3f start,Vector3f end,float size,Effect.Color color,int light,Effect.Uv uv) {
        Vector3f along=new Vector3f(end).sub(start);if(along.lengthSquared()<1e-9) return 0;
        Vector3f toward=new Vector3f(start).add(end).mul(-.5f);Vector3f side=along.cross(toward,new Vector3f());if(side.lengthSquared()<1e-9) side.set(1,0,0);side.normalize().mul(size*.5f);
        quad(pose,b,new Vector3f(start).sub(side),new Vector3f(end).sub(side),new Vector3f(end).add(side),new Vector3f(start).add(side),color,light,uv);return 1;
    }
    private static void quad(class_4587 p,class_4588 b,Vector3f a,Vector3f c,Vector3f d,Vector3f e,Effect.Color color,int light) { vertex(p,b,a,0,1,color,light);vertex(p,b,c,0,0,color,light);vertex(p,b,d,1,0,color,light);vertex(p,b,e,1,1,color,light); }
    private static void quad(class_4587 p,class_4588 b,Vector3f a,Vector3f c,Vector3f d,Vector3f e,Effect.Color color,int light,Effect.Uv uv) {vertex(p,b,a,(float)uv.u0(),(float)uv.v1(),color,light);vertex(p,b,c,(float)uv.u0(),(float)uv.v0(),color,light);vertex(p,b,d,(float)uv.u1(),(float)uv.v0(),color,light);vertex(p,b,e,(float)uv.u1(),(float)uv.v1(),color,light);}
    private static void vertex(class_4587 p,class_4588 b,Vector3f v,float u,float w,Effect.Color c,int light) { b.method_22918(p.method_23760().method_23761(),v.x,v.y,v.z).method_22915((float)c.r(),(float)c.g(),(float)c.b(),(float)c.a()).method_22913(u,w).method_22922(class_4608.field_21444).method_60803(light).method_60831(p.method_23760(),0,1,0); }
}
