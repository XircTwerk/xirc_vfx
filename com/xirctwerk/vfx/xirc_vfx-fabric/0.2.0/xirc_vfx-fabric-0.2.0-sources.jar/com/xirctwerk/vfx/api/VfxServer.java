package com.xirctwerk.vfx.api;

import com.xirctwerk.vfx.core.*;
import com.xirctwerk.vfx.core.Effect.*;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.level.*;
import java.util.*;
import java.util.function.*;

/** Server-thread API. No client classes are referenced here. Optional clients are skipped. */
public final class VfxServer {
    private VfxServer(){}
    private static BiConsumer<class_3222,PlaybackMessage> sender;
    private static Predicate<class_3222> supported;
    private static BiPredicate<class_3222,Vec> tracking;
    public static void installTransport(Predicate<class_3222> support,BiConsumer<class_3222,PlaybackMessage> send,BiPredicate<class_3222,Vec> tracked){supported=Objects.requireNonNull(support);sender=Objects.requireNonNull(send);tracking=Objects.requireNonNull(tracked);}
    public static Handle play(class_3218 level,class_2960 effect,Vec position,double range,long seed,Map<String,Double> parameters){return play(level,effect,position,range,seed,parameters,new Color(1,1,1,1),null,Vec.ZERO);}
    public static Handle attach(class_1297 entity,class_2960 effect,Vec offset,double range,long seed,Map<String,Double> parameters){
        if(!(entity.method_37908() instanceof class_3218 level)||entity.method_31481())throw new IllegalArgumentException("Attachment requires a live server entity");
        return play(level,effect,new Vec(entity.method_23317(),entity.method_23318(),entity.method_23321()),range,seed,parameters,new Color(1,1,1,1),entity.method_5667(),offset);
    }
    public static Handle play(class_3218 level,class_2960 effect,Vec position,double range,long seed,Map<String,Double> parameters,Color tint,UUID entity,Vec offset){
        if(!level.method_8503().method_18854())throw new IllegalStateException("VfxServer requires the server thread");
        if(!Double.isFinite(range)||range<1||range>256)throw new IllegalArgumentException("Delivery range must be 1..256 blocks");
        if(sender==null)throw new IllegalStateException("Loader networking has not initialized");
        var definition=Effects.get(effect);Parameters.override(definition.json(),parameters);
        var message=new PlaybackMessage(UUID.randomUUID(),false,effect.toString(),definition.digest(),level.method_27983().method_29177().toString(),position,seed,parameters,tint,entity,offset);
        List<class_3222> recipients=level.method_18456().stream().filter(p->p.method_5649(position.x(),position.y(),position.z())<=range*range&&supported.test(p)&&tracking.test(p,position)).toList();
        recipients.forEach(player->sender.accept(player,message));return new Handle(level,message,recipients.stream().map(class_1297::method_5667).toList());
    }
    public static final class Handle {
        private final class_3218 level;private final PlaybackMessage message;private final List<UUID> recipients;private boolean stopped;
        private Handle(class_3218 level,PlaybackMessage message,List<UUID> recipients){this.level=level;this.message=message;this.recipients=recipients;}
        public int recipients(){return recipients.size();}
        public void stop(){if(!level.method_8503().method_18854())throw new IllegalStateException("VfxServer requires the server thread");if(stopped)return;stopped=true;for(UUID id:recipients){var player=level.method_8503().method_3760().method_14602(id);if(player!=null&&supported.test(player))sender.accept(player,message.stopped());}}
    }
}
