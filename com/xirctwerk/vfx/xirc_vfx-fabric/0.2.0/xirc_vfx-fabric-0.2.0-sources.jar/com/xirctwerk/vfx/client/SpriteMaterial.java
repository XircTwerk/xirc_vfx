package com.xirctwerk.vfx.client;

import com.mojang.blaze3d.vertex.*;
import java.util.*;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;

/** Translucent sprites test world depth without writing faint sprite surfaces into it. */
final class SpriteMaterial extends class_1921 {
    private record Key(class_2960 texture,boolean glow,boolean additive,boolean bloom) {}
    private static final class_4685 ADDITIVE=new class_4685("xirc_additive",()->{com.mojang.blaze3d.systems.RenderSystem.enableBlend();com.mojang.blaze3d.systems.RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA,org.lwjgl.opengl.GL11.GL_ONE);},()->{com.mojang.blaze3d.systems.RenderSystem.disableBlend();com.mojang.blaze3d.systems.RenderSystem.defaultBlendFunc();});
    private static final class_4678 BLOOM_OUTPUT=new class_4678("xirc_bloom",BloomRenderer::bindSource,()->{});
    private static final Map<Key,class_1921> CACHE=new LinkedHashMap<>(256,.75f,true) {
        @Override protected boolean removeEldestEntry(Map.Entry<Key,class_1921> e) {return size()>256;}
    };
    private SpriteMaterial() {super("xirc_sprite",class_290.field_1580,class_293.class_5596.field_27382,256,false,true,()->{},()->{});}
    static class_1921 get(class_2960 texture,boolean glow,boolean additive,boolean bloom) {
        return CACHE.computeIfAbsent(new Key(texture,glow,additive,bloom),key->method_24049("xirc_sprite",class_290.field_1580,class_293.class_5596.field_27382,1536,false,true,
            class_4688.method_23598().method_34578(glow?field_38344:field_29407)
                .method_34577(new class_4683(texture,false,false)).method_23615(additive?ADDITIVE:field_21370).method_23610(bloom?BLOOM_OUTPUT:field_21358)
                .method_23603(field_21345).method_23608(field_21383).method_23611(field_21385).method_23616(field_21350).method_23617(false)));
    }
}
