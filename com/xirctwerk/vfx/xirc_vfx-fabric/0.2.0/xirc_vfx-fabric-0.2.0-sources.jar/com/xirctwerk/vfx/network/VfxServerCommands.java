package com.xirctwerk.vfx.network;

import com.xirctwerk.vfx.api.*;
import com.xirctwerk.vfx.core.Effect.*;
import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.commands.*;
import java.util.Map;

/** Explicit operator-only network example; never reacts to normal combat automatically. */
public final class VfxServerCommands {
    private VfxServerCommands(){}
    public static void register(CommandDispatcher<class_2168> dispatcher){
        dispatcher.register(class_2170.method_9247("xvfx-server").requires(s->s.method_9259(2)).then(class_2170.method_9247("demo").executes(c->{
            var source=c.getSource();var p=source.method_9222();
            var handle=VfxServer.play(source.method_9225(),class_2960.method_60654("xirc_vfx:example/impact"),new Vec(p.field_1352,p.field_1351+1,p.field_1350+3),64,42,Map.of("power",2.5,"radius",2.));
            source.method_9226(()->class_2561.method_43470("Xirc's VFX: sent example to "+handle.recipients()+" supported clients in range."),false);return 1;
        })));
    }
}
