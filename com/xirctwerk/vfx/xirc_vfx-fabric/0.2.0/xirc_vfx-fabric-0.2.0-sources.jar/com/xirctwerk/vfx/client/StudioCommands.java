package com.xirctwerk.vfx.client;

import com.mojang.brigadier.*;
import com.mojang.brigadier.arguments.*;
import com.mojang.brigadier.builder.*;
import com.mojang.brigadier.context.CommandContext;
import com.xirctwerk.vfx.core.*;
import java.util.function.BiConsumer;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;

public final class StudioCommands {
    private interface Action<S> { void run(CommandContext<S> context) throws Exception; }
    private static <S> Command<S> execute(BiConsumer<S,class_2561> feedback,Action<S> action) { return c->{ try { action.run(c);return 1; } catch(Exception e) { feedback.accept(c.getSource(),class_2561.method_43470("Studio: "+e.getMessage()));return 0; } }; }
    private static <S> LiteralArgumentBuilder<S> lit(String name) { return LiteralArgumentBuilder.literal(name); }
    private static <S,T> RequiredArgumentBuilder<S,T> arg(String name,ArgumentType<T> type) { return RequiredArgumentBuilder.argument(name,type); }
    private static <S> RequiredArgumentBuilder<S,String> name() { return StudioCommands.<S,String>arg("name",StringArgumentType.word()).suggests((c,b)->{ try { VfxClient.INSTANCE.files.list().forEach(b::suggest); }catch(Exception ignored){} return b.buildFuture(); }); }
    private static Effect.Vec me() { var player=class_310.method_1551().field_1724;if(player==null) throw new IllegalStateException("Join a world first.");return VfxClient.vec(player.method_19538()); }
    public static <S> void register(CommandDispatcher<S> dispatcher,BiConsumer<S,class_2561> feedback) {
        var studio=VfxClient.INSTANCE;
        LiteralArgumentBuilder<S> root=StudioCommands.<S>lit("xvfx").executes(execute(feedback,c->class_310.method_1551().execute(studio::open)));
        root.then(StudioCommands.<S>lit("editor").executes(execute(feedback,c->class_310.method_1551().execute(studio::open))));
        root.then(StudioCommands.<S>lit("stop").executes(execute(feedback,c->{studio.stop();feedback.accept(c.getSource(),class_2561.method_43470("Stopped all Studio effects."));})));
        root.then(StudioCommands.<S>lit("list").executes(execute(feedback,c->feedback.accept(c.getSource(),class_2561.method_43470(String.join(", ",studio.files.list()))))));
        var play=StudioCommands.<S>name().executes(execute(feedback,c->studio.play(StringArgumentType.getString(c,"name"),me())));
        play.then(StudioCommands.<S,Double>arg("x",DoubleArgumentType.doubleArg(-30000000,30000000)).then(StudioCommands.<S,Double>arg("y",DoubleArgumentType.doubleArg(-2048,2048)).then(StudioCommands.<S,Double>arg("z",DoubleArgumentType.doubleArg(-30000000,30000000)).executes(execute(feedback,c->studio.play(StringArgumentType.getString(c,"name"),new Effect.Vec(DoubleArgumentType.getDouble(c,"x"),DoubleArgumentType.getDouble(c,"y"),DoubleArgumentType.getDouble(c,"z"))))))));
        root.then(StudioCommands.<S>lit("play").then(play));
        root.then(StudioCommands.<S>lit("me").then(StudioCommands.<S>name().executes(execute(feedback,c->{me();studio.attach(StringArgumentType.getString(c,"name"),class_310.method_1551().field_1724.method_5628());}))));
        root.then(StudioCommands.<S>lit("attach").then(StudioCommands.<S>name().then(StudioCommands.<S,Integer>arg("entity_id",IntegerArgumentType.integer(0)).executes(execute(feedback,c->studio.attach(StringArgumentType.getString(c,"name"),IntegerArgumentType.getInteger(c,"entity_id")))))));
        root.then(StudioCommands.<S>lit("block").then(StudioCommands.<S>name().then(StudioCommands.<S,Integer>arg("x",IntegerArgumentType.integer(-30000000,30000000)).then(StudioCommands.<S,Integer>arg("y",IntegerArgumentType.integer(-2048,2048)).then(StudioCommands.<S,Integer>arg("z",IntegerArgumentType.integer(-30000000,30000000)).executes(execute(feedback,c->studio.block(StringArgumentType.getString(c,"name"),new class_2338(IntegerArgumentType.getInteger(c,"x"),IntegerArgumentType.getInteger(c,"y"),IntegerArgumentType.getInteger(c,"z"))))))))));
        root.then(StudioCommands.<S>lit("import").then(StudioCommands.<S,String>arg("name",StringArgumentType.word()).executes(execute(feedback,c->{String name=StringArgumentType.getString(c,"name");studio.importPackage(name);feedback.accept(c.getSource(),class_2561.method_43470("Imported "+name+".xvfx"));}))));
        var demos=StudioCommands.<S>lit("demo");
        for(String example:com.xirctwerk.vfx.api.IntegrationExamples.NAMES)demos.then(StudioCommands.<S>lit(example).executes(execute(feedback,c->{com.xirctwerk.vfx.api.IntegrationExamples.start(example);feedback.accept(c.getSource(),class_2561.method_43470("Started built-in example: "+example));})));
        demos.then(StudioCommands.<S>lit("stop").executes(execute(feedback,c->com.xirctwerk.vfx.api.IntegrationExamples.stop())));root.then(demos);
        root.then(StudioCommands.<S>lit("profile").executes(execute(feedback,c->{for(var row:com.xirctwerk.vfx.api.VfxPerformance.snapshot())feedback.accept(c.getSource(),class_2561.method_43470(row.toString()));})));
        dispatcher.register(root);
    }
}
