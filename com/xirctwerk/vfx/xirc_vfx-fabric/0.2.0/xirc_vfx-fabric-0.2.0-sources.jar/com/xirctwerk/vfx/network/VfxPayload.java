package com.xirctwerk.vfx.network;

import com.xirctwerk.vfx.core.PlaybackMessage;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record VfxPayload(PlaybackMessage message) implements class_8710 {
    public static final class_9154<VfxPayload> TYPE=new class_9154<>(class_2960.method_60655("xirc_vfx","playback_v1"));
    public static final class_9139<class_9129,VfxPayload> CODEC=new class_9139<>(){
        public VfxPayload decode(class_9129 buffer){return new VfxPayload(PlaybackMessage.decode(buffer.method_10803(PlaybackMessage.MAX_BYTES)));}
        public void encode(class_9129 buffer,VfxPayload value){buffer.method_10813(value.message.encode());}
    };
    @Override public class_9154<? extends class_8710> method_56479(){return TYPE;}
}
