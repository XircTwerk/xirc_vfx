package com.xirctwerk.vfx.api;

import com.xirctwerk.vfx.core.*;
import com.xirctwerk.vfx.core.Effect.*;
import com.xirctwerk.vfx.client.VfxClient;
import java.io.IOException;
import net.minecraft.class_1297;
import net.minecraft.class_310;

/** Entity-local anchor offsets; callers may use players, weapons' owners or projectiles. */
public final class Attachments {
    private Attachments(){}
    public enum MissingTarget { STOP, FADE_OUT, DETACH }
    public static Vfx.Handle attach(Project project,class_1297 target,Vec offset,boolean followYaw,MissingTarget missing) throws IOException {
        return attach(project,target,offset,followYaw,missing,project.effect().seed());
    }
    public static Vfx.Handle attach(Project project,class_1297 target,Vec offset,boolean followYaw,MissingTarget missing,long seed) throws IOException {
        Vfx.checkThread();PlaybackControls.finite(offset);java.util.Objects.requireNonNull(missing);var world=class_310.method_1551().field_1687;
        if(world==null||target==null||target.method_37908()!=world||target.method_31481())throw new IOException("Attachment requires a loaded entity in the current world");
        Vec[] last={VfxClient.vec(target.method_19538()).add(offset)};boolean[] lost={false};VfxClient.Playback[] handle={null};
        var result=VfxClient.INSTANCE.play(project,()->{
            if(!lost[0])last[0]=VfxClient.vec(target.method_19538()).add(followYaw?Transforms.Pose.euler(Vec.ZERO,new Vec(0,-target.method_36454(),0),1).vector(offset):offset);return last[0];
        },()->{
            if(class_310.method_1551().field_1687!=world)return false;
            if(!lost[0]&&(target.method_31481()||world.method_8469(target.method_5628())!=target)){
                lost[0]=true;if(missing==MissingTarget.FADE_OUT&&handle[0]!=null)handle[0].pause(false).fadeOut(.25);
            }
            return !lost[0]||missing!=MissingTarget.STOP;
        },seed);handle[0]=result;return result;
    }
}
