package com.xirctwerk.vfx.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_6367;
import net.minecraft.client.*;
import org.lwjgl.opengl.*;
import java.nio.charset.StandardCharsets;
import java.io.*;

/** Independent effect-only bloom orchestration. Gaussian fragment shader reused from MIT Shimmer. */
final class BloomRenderer {
    private static class_6367 source;
    private static final class_6367[] horizontal=new class_6367[3],vertical=new class_6367[3];
    private static int blur,combine,vao;
    private static boolean failed;
    private static long frames;
    static long frames() {return frames;}
    static void bindSource() {if(source!=null)source.method_1235(true);}
    static void render(class_4587 pose,class_4184 camera) {
        var mc=class_310.method_1551();if(mc.field_1687==null){release();return;}
        if(failed||(!GeometryRenderer.hasBloom()&&VfxClient.INSTANCE.playbacks().stream().noneMatch(p->p.simulation().particles().stream().anyMatch(v->v.emitter.bloom()>0))))return;
        var main=mc.method_1522();if(main.field_1482>4096||main.field_1481>4096)return;
        var shader=RenderSystem.getShader();int program=GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM),oldVao=GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
        int draw=GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING),read=GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
        if(draw!=main.field_1476)return; // Respect foreign/off-screen targets; do not leak a post pass into the game window.
        int[] viewport=new int[4];GL11.glGetIntegerv(GL11.GL_VIEWPORT,viewport);
        int active=GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);int[] textures=new int[3];for(int i=0;i<3;i++){RenderSystem.activeTexture(GL13.GL_TEXTURE0+i);textures[i]=GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);}RenderSystem.activeTexture(active);
        boolean blend=GL11.glIsEnabled(GL11.GL_BLEND),depth=GL11.glIsEnabled(GL11.GL_DEPTH_TEST),cull=GL11.glIsEnabled(GL11.GL_CULL_FACE),scissor=GL11.glIsEnabled(GL11.GL_SCISSOR_TEST),mask=GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);
        int srcRgb=GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB),dstRgb=GL11.glGetInteger(GL14.GL_BLEND_DST_RGB),srcAlpha=GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA),dstAlpha=GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
        int equationRgb=GL11.glGetInteger(GL20.GL_BLEND_EQUATION_RGB),equationAlpha=GL11.glGetInteger(GL20.GL_BLEND_EQUATION_ALPHA);
        float[] clear=new float[4];GL11.glGetFloatv(GL11.GL_COLOR_CLEAR_VALUE,clear);
        var colorMask=org.lwjgl.BufferUtils.createByteBuffer(4);GL11.glGetBooleanv(GL11.GL_COLOR_WRITEMASK,colorMask);
        try {
            prepare(main.field_1482,main.field_1481);GL11.glDisable(GL11.GL_SCISSOR_TEST);RenderSystem.colorMask(true,true,true,true);
            source.method_1236(0,0,0,0);source.method_1230(class_310.field_1703);source.method_29329(main);source.method_1235(true);
            VfxRenderer.renderParticles(pose,camera,true);GeometryRenderer.renderBloom(pose,camera);
            RenderSystem.disableDepthTest();RenderSystem.depthMask(false);RenderSystem.disableCull();RenderSystem.disableBlend();
            GL30.glBindVertexArray(vao);
            for(int i=0;i<3;i++) {
                fullscreen(horizontal[i],source.method_30277(),blur,1,0,1);
                fullscreen(vertical[i],horizontal[i].method_30277(),blur,0,1,1);
                main.method_1235(true);RenderSystem.enableBlend();RenderSystem.blendFuncSeparate(GL11.GL_ONE,GL11.GL_ONE,GL11.GL_ZERO,GL11.GL_ONE);GL20.glBlendEquationSeparate(GL14.GL_FUNC_ADD,GL14.GL_FUNC_ADD);
                fullscreen(null,vertical[i].method_30277(),combine,0,0,4f/3f);RenderSystem.disableBlend();
            }
            frames++;
        }catch(Exception e){failed=true;org.slf4j.LoggerFactory.getLogger("XircBloom").error("Bloom disabled after a render failure; base effects remain available",e);}
        finally {
            GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER,draw);GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER,read);RenderSystem.viewport(viewport[0],viewport[1],viewport[2],viewport[3]);
            RenderSystem.setShader(()->shader);GlStateManager._glUseProgram(program);GL30.glBindVertexArray(oldVao);
            for(int i=0;i<3;i++){RenderSystem.activeTexture(GL13.GL_TEXTURE0+i);RenderSystem.bindTexture(textures[i]);}RenderSystem.activeTexture(active);
            RenderSystem.blendFuncSeparate(srcRgb,dstRgb,srcAlpha,dstAlpha);GL20.glBlendEquationSeparate(equationRgb,equationAlpha);RenderSystem.depthMask(mask);RenderSystem.clearColor(clear[0],clear[1],clear[2],clear[3]);
            RenderSystem.colorMask(colorMask.get(0)!=0,colorMask.get(1)!=0,colorMask.get(2)!=0,colorMask.get(3)!=0);
            if(blend)RenderSystem.enableBlend();else RenderSystem.disableBlend();if(depth)RenderSystem.enableDepthTest();else RenderSystem.disableDepthTest();if(cull)RenderSystem.enableCull();else RenderSystem.disableCull();if(scissor)GL11.glEnable(GL11.GL_SCISSOR_TEST);else GL11.glDisable(GL11.GL_SCISSOR_TEST);
        }
    }
    private static void prepare(int width,int height)throws IOException {
        if(blur==0){String vertex="#version 150\nout vec2 texCoord;void main(){vec2 p=vec2((gl_VertexID<<1)&2,gl_VertexID&2);texCoord=p;gl_Position=vec4(p*2.0-1.0,0,1);}";
            try(var in=BloomRenderer.class.getResourceAsStream("/assets/xirc_vfx_studio/shaders/post/shimmer_blur.fsh")){if(in==null)throw new IOException("Missing bundled Shimmer blur shader");blur=program(vertex,new String(in.readAllBytes(),StandardCharsets.UTF_8));}
            combine=program(vertex,"#version 150\nuniform sampler2D DiffuseSampler;uniform float Gain;in vec2 texCoord;out vec4 fragColor;void main(){fragColor=vec4(texture(DiffuseSampler,texCoord).rgb*Gain,0);}");vao=GL30.glGenVertexArrays();
        }
        if(source==null)source=new class_6367(width,height,true,class_310.field_1703);else if(source.field_1482!=width||source.field_1481!=height)source.method_1234(width,height,class_310.field_1703);
        for(int i=0;i<3;i++){int w=Math.max(1,(width+(1<<(i+1))-1)>>(i+1)),h=Math.max(1,(height+(1<<(i+1))-1)>>(i+1));
            if(horizontal[i]==null){horizontal[i]=new class_6367(w,h,false,class_310.field_1703);vertical[i]=new class_6367(w,h,false,class_310.field_1703);}else if(horizontal[i].field_1482!=w||horizontal[i].field_1481!=h){horizontal[i].method_1234(w,h,class_310.field_1703);vertical[i].method_1234(w,h,class_310.field_1703);}
            horizontal[i].method_58226(GL11.GL_LINEAR);vertical[i].method_58226(GL11.GL_LINEAR);
        }source.method_58226(GL11.GL_LINEAR);
    }
    private static void fullscreen(class_6367 target,int texture,int program,float x,float y,float gain) {
        if(target!=null)target.method_1235(true);GlStateManager._glUseProgram(program);RenderSystem.activeTexture(GL13.GL_TEXTURE0);RenderSystem.bindTexture(texture);GL20.glUniform1i(GL20.glGetUniformLocation(program,"DiffuseSampler"),0);
        GL20.glUniform1f(GL20.glGetUniformLocation(program,"Gain"),gain);GL20.glUniform2f(GL20.glGetUniformLocation(program,"BlurDir"),x,y);GL20.glUniform1i(GL20.glGetUniformLocation(program,"Radius"),8);
        if(target!=null)GL20.glUniform2f(GL20.glGetUniformLocation(program,"OutSize"),target.field_1482,target.field_1481);GL11.glDrawArrays(GL11.GL_TRIANGLES,0,3);
    }
    private static int program(String vertex,String fragment)throws IOException {
        int v=compile(GL20.GL_VERTEX_SHADER,vertex),f=0,p=0;try{f=compile(GL20.GL_FRAGMENT_SHADER,fragment);p=GL20.glCreateProgram();GL20.glAttachShader(p,v);GL20.glAttachShader(p,f);GL20.glLinkProgram(p);if(GL20.glGetProgrami(p,GL20.GL_LINK_STATUS)==0)throw new IOException(GL20.glGetProgramInfoLog(p));return p;}catch(IOException e){if(p!=0)GL20.glDeleteProgram(p);throw e;}finally{GL20.glDeleteShader(v);if(f!=0)GL20.glDeleteShader(f);}
    }
    private static int compile(int type,String text)throws IOException {int id=GL20.glCreateShader(type);GL20.glShaderSource(id,text);GL20.glCompileShader(id);if(GL20.glGetShaderi(id,GL20.GL_COMPILE_STATUS)==0){String error=GL20.glGetShaderInfoLog(id);GL20.glDeleteShader(id);throw new IOException(error);}return id;}
    static void release(){if(source!=null){source.method_1238();source=null;}for(int i=0;i<3;i++)if(horizontal[i]!=null){horizontal[i].method_1238();vertical[i].method_1238();horizontal[i]=vertical[i]=null;}if(blur!=0)GL20.glDeleteProgram(blur);if(combine!=0)GL20.glDeleteProgram(combine);if(vao!=0)GL30.glDeleteVertexArrays(vao);blur=combine=vao=0;failed=false;}
}
